# ربات تبلیغاتی مستقل آبتین مپس

این ربات هیچ اتصال یا وابستگی به پروژه آبتین دیست ندارد و فقط برای معرفی اپلیکیشن آبتین مپس ساخته شده است.

## امکانات

- معرفی برنامه
- نمایش امکانات برنامه
- راهنمای نصب
- لینک دانلود نسخه اندروید (همیشه آخرین ریلیز، خودکار از GitHub)
- لینک صفحه انتشار نسخه
- اشتراک‌گذاری با دوستان

شمارهٔ نسخه، لینک APK و صفحهٔ ریلیز از API گیتهاب (`releases/latest`) خوانده و ۱۰ دقیقه کش می‌شوند؛ با انتشار نسخهٔ جدید نیازی به تغییر کد نیست. اگر گیتهاب در دسترس نباشد، دکمه‌ها به صفحهٔ `releases/latest` می‌روند.

نکته: `releases/latest` فقط ریلیزهای منتشرشدهٔ غیر pre-release را برمی‌گرداند، و APK باید به‌عنوان asset به ریلیز پیوست شده باشد.

## اجرا روی Railway

1. این پوشه را در یک مخزن جدید گیتهاب بگذارید (`.gitignore` توکن و `.venv` را کنار می‌گذارد).
2. در Railway: **New Project → Deploy from GitHub repo** و همان مخزن را انتخاب کنید.
3. در تب **Variables** این متغیر را بسازید:
   - `TELEGRAM_BOT_TOKEN` — توکن از BotFather (اجباری)
   - `GITHUB_REPO` — پیش‌فرض `abtin123/Project` (اختیاری)
   - `GITHUB_TOKEN` — اختیاری؛ فقط اگر به محدودیت نرخ API گیتهاب خوردید
4. Deploy کنید. فایل `railway.json` دستور شروع (`python bot.py`) و راه‌اندازی مجدد خودکار در صورت خطا را تنظیم کرده است.
5. این یک سرویس worker است و نیازی به Domain یا پورت ندارد؛ لاگ‌ها باید پیام `Abtin Maps Telegram bot is running` را نشان دهند.

توکن را داخل Git، ZIP یا فایل عمومی قرار ندهید. اگر لو رفت، با `/revoke` در BotFather توکن جدید بگیرید.

## اجرا روی هر سرور (Docker)

```bash
cp .env.example .env   # TELEGRAM_BOT_TOKEN را داخل .env بنویسید
docker compose up -d --build
docker compose logs -f
```

بدون Docker روی VPS: فایل `abtinmaps-bot.service` را با systemd استفاده کنید (توضیح بالای همان فایل).
همین `Dockerfile` روی Koyeb، Fly.io، Render و بیشتر سرویس‌های دیگر هم کار می‌کند؛ نوع سرویس باید worker یا پروسهٔ پس‌زمینه باشد (پورت لازم نیست).

## اجرای محلی

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
export TELEGRAM_BOT_TOKEN='توکن ربات'
.venv/bin/python bot.py
```
